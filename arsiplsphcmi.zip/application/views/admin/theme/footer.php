<footer class="main-footer text-center text-sm">
    <strong>Copyright &copy; 2021 <a href="https://lsphcmi.com">LSP HCMI</a>.</strong> All rights reserved.
</footer>